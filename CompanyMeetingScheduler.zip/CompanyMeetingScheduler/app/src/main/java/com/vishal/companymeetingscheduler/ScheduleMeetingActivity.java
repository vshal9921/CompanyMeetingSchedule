package com.vishal.companymeetingscheduler;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ScheduleMeetingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule_meeting);
    }
}
